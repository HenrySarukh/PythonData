"""
Скрипт содерджит все функции, 
которые нужны для работы с 
данными.
Также содержит функции для 
интерфейса.
Автор: Саруханян,Юсупов
Группа: БИВ181
Бригада: 4
"""



import tkinter as tk
import tkinter.ttk as ttk
import pandas as pd
from tkinter import filedialog
import os
import matplotlib.pyplot as plt 
import numpy as np
workDir = os.getcwd()
workDir = workDir.replace("Scripts", "")

####################################
#menu 
color_bgEn = "#2a5885"
color_abg = "#3F5AF1"  
colro_afg = "#ffffff"
color_bg = "#4a75a8"
color_fg = "white"
#positive


color1_abg = "#57bf57"  
color1_bg = "#10d410"
color1_fg = "white"

#negative

color2_abg = "#a51a04"  
color2_bg = "#e82d0f"
color2_fg = "white"    
##################################



pd.options.mode.chained_assignment = None

xls = ""

Baza = pd.DataFrame(index=None, columns=None)



def HideWin(SelWin):   
    SelWin.withdraw()
def Back(win1=None,win2=None):
    win1.deiconify()
    win2.destroy()
     
def Open(mainR, but1,but2,but3,but4):
    global Baza
    global workDir
    openWin=tk.Tk()    
    openWin.protocol("WM_DELETE_WINDOW",lambda: Back(mainR,openWin))
    w = openWin.winfo_screenwidth() 
    h = openWin.winfo_screenheight() 
    w = w//2
    h = h//2
    w = w - 200 
    h = h - 200
    openWin.title('Project 4')
    openWin.iconbitmap(workDir + 'Graphics\\icon.ico')

    
    HideWin(mainR)
    def clickOp(lbl,bt1,bt2,bt3,bt4):
        global xls
        xls=filedialog.Open(initialdir=workDir+"Data\\", filetypes=[("*.pkl files", ".pkl")]).show()
        global Baza        
        try:
            Baza = pd.read_pickle(xls)
            lbl.config(text="Файл загружен", bg=color1_bg)
            bt1['state']='normal'
            bt2['state']='normal'
            bt3['state']='normal'
            bt4['state']='normal'
        except:
            pass
        try:
            del Baza['Unnamed: 0']
        except:
            pass
    
        
    lbRoot = tk.Label(openWin, text="Файл не загружен", bg=color2_bg, font=('Comic Sans MS', 11), fg=color_fg, relief='ridge', width=24, height=1)
    btnOp = tk.Button(openWin,  text='Загрузить файл', width=24, height=1, 
                                 activebackground=color_abg, activeforeground=colro_afg, bg=color_abg, font=('Comic Sans MS', 11), fg=color_fg, relief='flat', command=lambda: clickOp(lbRoot,but1,but2,but3,but4))
    btnBack = tk.Button(openWin,  text='Назад', width=24, height=1,
                                 activebackground=color_abg, activeforeground=colro_afg,bg=color_abg, font=('Comic Sans MS', 11), fg=color_fg, relief='flat', command=lambda: Back(mainR,openWin))
    lbRoot.pack(padx=10, pady=10)
    btnOp.pack(padx=10, pady=10)
    btnBack.pack(padx=10, pady=10)
    openWin.configure(bg='white')
    openWin.geometry('330x400+{}+{}'.format(w, h))
    openWin.minsize(330,400)
    
    openWin.mainloop()



def Add(mainR=None): 
    addWin=tk.Tk()
    addWin.title('Project 4')
    addWin.iconbitmap(workDir + 'Graphics/icon.ico')
    HideWin(mainR)
    addWin.protocol("WM_DELETE_WINDOW",lambda: Back(mainR,addWin))
    def click(idL,labl):
        global Baza
        nazv=txt.get()     
        tip=txt1.get()
        brend=txt2.get()
        ves=txt3.get()
        cena=txt4.get()
        tel=txt5.get()
        adr=txt6.get()
        try:
            Q={'ID':int(idL),'Название':nazv,'Тип':tip,'Бренд':brend,'Вес/Объем':float(ves),
                       'Цена':float(cena),'Телефон':tel,'Адрес':adr}            
            txt.delete(0,"end")
            txt1.delete(0,"end")
            txt2.delete(0,"end")
            txt3.delete(0,"end")
            txt4.delete(0,"end")
            txt5.delete(0,"end")
            txt6.delete(0,"end")
            H = pd.DataFrame(Q,index = [0])
            Baza = Baza.append(H,ignore_index=True)
            labl.config(text=idL+1)
        except:
            pass
        
    lb1 = tk.Label(addWin, text='ID',  
                        bg=color_abg,fg=color_fg, width=5, height=1)
    lb2 = tk.Label(addWin, text='Название',  
                        bg=color_abg,fg=color_fg, width=35, height=1)
    lb3 = tk.Label(addWin, text='Тип',  
                        bg=color_abg,fg=color_fg, width=30, height=1)
    lb4 = tk.Label(addWin, text='Бренд', 
                        bg=color_abg,fg=color_fg, width=24, height=1)
    lb5 = tk.Label(addWin, text='Вес/Объем (любое число)',  
                        bg=color_abg,fg=color_fg, width=24, height=1)
    lb6 = tk.Label(addWin, text='Цена (любое число)',  
                        bg=color_abg,fg=color_fg, width=17, height=1)
    lb7 = tk.Label(addWin, text='Телефон', 
                        bg=color_abg,fg=color_fg, width=18, height=1)
    lb8 = tk.Label(addWin, text='Адрес', 
                        bg=color_abg,fg=color_fg, width=30, height=1)
    lb9 = tk.Label(addWin, text=Baza['ID'].iloc[-1]+1,  
                        bg='white',fg='black', width=5, height=1)
    lb1.grid(column=0, row=0)
    lb2.grid(column=1, row=0)
    lb3.grid(column=2, row=0)
    lb4.grid(column=3, row=0)
    lb5.grid(column=4, row=0)
    lb6.grid(column=5, row=0)
    lb7.grid(column=6, row=0)
    lb8.grid(column=7, row=0)
    lb9.grid(column=0, row=1)
        
    txt = tk.Entry(addWin,width=35)        
    txt1 = tk.Entry(addWin,width=30)
    txt2 = tk.Entry(addWin,width=24)
    txt3 = tk.Entry(addWin,width=24)
    txt4 = tk.Entry(addWin,width=17)
    txt5 = tk.Entry(addWin,width=18)
    txt6 = tk.Entry(addWin,width=30)
        
        
        
    txt.grid(column=1, row=1, pady=20)
    txt1.grid(column=2, row=1, pady=20) 
    txt2.grid(column=3, row=1, pady=20)
    txt3.grid(column=4, row=1, pady=20) 
    txt4.grid(column=5, row=1, pady=20)
    txt5.grid(column=6, row=1, pady=20) 
    txt6.grid(column=7, row=1, pady=20)
        
         
        
        
        
        
    btn = tk.Button(addWin,  text='Добавить', width=20, 
                         relief="raised", bg=color1_bg,  fg=color_fg,command=lambda: click(Baza['ID'].iloc[-1]+1,lb9))
    btn.grid(column=4, row=3, pady=20)
    btnBack = tk.Button(addWin,  text='Назад', width=20, 
                         relief="raised", bg=color1_bg,  fg=color_fg,command=lambda: Back(mainR,addWin))
    btnBack.grid(column=4, row=4, pady=20)    
    addWin.minsize(1300,400)
    addWin.mainloop()








def Pokaz(mainR=None):
    
    def clck7():
        global Baza
        table.delete(*table.get_children())
        z = 0
        Kaza = Baza
        for x in Kaza['ID']:
            k = []
            for y in Kaza:
                h = []
                h = (Kaza[y][Kaza['ID'] == x]).tolist()
                k.append(h[0])
            z+=1
            if(z%2==0):
                table.insert('', tk.END, values = k, tag='1')
            elif(int(z)%2==1):
                table.insert('', tk.END, values = k, tag='2')

    def clck1():
        global Baza
        table.delete(*table.get_children())
        z = 0
        Kaza = Baza.sort_values('Название')
        for x in Kaza['ID']:
            k = []
            for y in Kaza:
                h = []
                h = (Kaza[y][Kaza['ID'] == x]).tolist()
                k.append(h[0])
            z+=1
            if(z%2==0):
                table.insert('', tk.END, values = k, tag='1')
            elif(int(z)%2==1):
                table.insert('', tk.END, values = k, tag='2')
      
    def clck2():
        global Baza
        table.delete(*table.get_children())
        z = 0
        Kaza = Baza.sort_values('Тип')
        for x in Kaza['ID']:
            k = []
            for y in Kaza:
                h = []
                h = (Kaza[y][Kaza['ID'] == x]).tolist()
                k.append(h[0])
            z+=1
            if(z%2==0):
                table.insert('', tk.END, values = k, tag='3')
            elif(int(z)%2==1):
                table.insert('', tk.END, values = k, tag='4')
               
    def clck3():
        global Baza
        table.delete(*table.get_children())
        z = 0
        Kaza = Baza.sort_values('Цена')
        for x in Kaza['ID']:
            k = []
            for y in Kaza:
                h = []
                h = (Kaza[y][Kaza['ID'] == x]).tolist()
                k.append(h[0])
            z+=1
            if(z%2==0):
                table.insert('', tk.END, values = k, tag='5')
            elif(int(z)%2==1):
                table.insert('', tk.END, values = k, tag='6')            
    
    def clck4():
        global Baza
        table.delete(*table.get_children())
        z = 0
        Kaza = Baza.sort_values('Бренд')
        for x in Kaza['ID']:
            k = []
            for y in Kaza:
                h = []
                h = (Kaza[y][Kaza['ID'] == x]).tolist()
                k.append(h[0])
            z+=1
            if(z%2==0):
                table.insert('', tk.END, values = k, tag='7')
            elif(int(z)%2==1):
                table.insert('', tk.END, values = k, tag='8')
    
      
    def delete():
        global Baza
        try:
            selected_item = table.selection()[0]
            curItem = table.focus()
            i = table.item(curItem)['values'][0]
            table.delete(selected_item)
            Baza = Baza.drop(Baza.loc[Baza['ID'] == i].index)
        except:
            print('')
    
    def saving():
        global Baza
        global xls
        Baza.to_pickle(xls) 
        
        
    def DK(event):
        global Baza
        
        def clickSave(ind=None,root1=None,root2=None):
            global Baza
            nazv=txt.get() 
            tip=txt1.get()
            brend=txt2.get()
            ves=txt3.get()
            cena=txt4.get()
            tel=txt5.get()
            adr=txt6.get()                     
            Baza['Название'][Baza.loc[Baza['ID'] == ind].index] = nazv
            Baza['Тип'][Baza.loc[Baza['ID'] == ind].index] = tip
            Baza['Бренд'][Baza.loc[Baza['ID'] == ind].index] = brend
            Baza['Вес/Объем'][Baza.loc[Baza['ID'] == ind].index] = float(ves)
            Baza['Цена'][Baza.loc[Baza['ID'] == ind].index] = float(cena)
            Baza['Телефон'][Baza.loc[Baza['ID'] == ind].index] = tel
            Baza['Адрес'][Baza.loc[Baza['ID'] == ind].index] = adr
            clck7()       
            Back(root1,root2)
        

        editWin=tk.Tk()
        editWin.title('Project 4')
        editWin.iconbitmap(workDir + 'Graphics/icon.ico')
        HideWin(tableWin)
        editWin.protocol("WM_DELETE_WINDOW",lambda: Back(tableWin,editWin))
        selected_item = table.selection()[0]
        curItem = table.focus()
        i = table.item(curItem)['values'][0]
        lb1 = tk.Label(editWin, text='ID',  
                            width=10, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
        lb2 = tk.Label(editWin, text='Название',  
                            width=35, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
        lb3 = tk.Label(editWin, text='Тип',  
                            width=28, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
        lb4 = tk.Label(editWin, text='Бренд', 
                            width=23, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
        lb5 = tk.Label(editWin, text='Вес/Объем',  
                            width=10, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
        lb6 = tk.Label(editWin, text='Цена',  
                            width=13, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
        lb7 = tk.Label(editWin, text='Телефон', 
                            width=16, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
        lb8 = tk.Label(editWin, text='Адрес', 
                            width=48, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
        lb9 = tk.Label(editWin, text=i,  
                            width=10, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
        lb1.grid(column=0, row=0)
        lb2.grid(column=1, row=0)
        lb3.grid(column=2, row=0)
        lb4.grid(column=3, row=0)
        lb5.grid(column=4, row=0)
        lb6.grid(column=5, row=0)
        lb7.grid(column=6, row=0)
        lb8.grid(column=7, row=0)
        lb9.grid(column=0, row=1)
        txt = tk.Entry(editWin,width=40) 
        
        txt1 = tk.Entry(editWin,width=33)
        txt2 = tk.Entry(editWin,width=28)
        txt3 = tk.Entry(editWin,width=12)
        txt4 = tk.Entry(editWin,width=15)
        txt5 = tk.Entry(editWin,width=18)
        txt6 = tk.Entry(editWin,width=53)
        txt.insert(0, Baza['Название'][i-1])
        txt1.insert(0, Baza['Тип'][i-1])
        txt2.insert(0, Baza['Бренд'][i-1])
        txt3.insert(0, Baza['Вес/Объем'][i-1])
        txt4.insert(0, Baza['Цена'][i-1])
        txt5.insert(0, Baza['Телефон'][i-1])
        txt6.insert(0, Baza['Адрес'][i-1])
            
            
            
        txt.grid(column=1, row=1, pady=20)
        txt1.grid(column=2, row=1, pady=20) 
        txt2.grid(column=3, row=1, pady=20)
        txt3.grid(column=4, row=1, pady=20) 
        txt4.grid(column=5, row=1, pady=20)
        txt5.grid(column=6, row=1, pady=20) 
        txt6.grid(column=7, row=1, pady=20)
        btn = tk.Button(editWin,  text='Сохранить', 
                     relief="raised",width=48, height=1, bg='#10e701',  fg=color_fg,command=lambda:clickSave(ind=i,root1=tableWin,root2=editWin))
        btn.grid(column=7, row=2, pady=20)
        btnBack = tk.Button(editWin,  text='Назад', relief="raised",width=13, height=1, bg=color2_bg,  fg=color_fg,command=lambda: Back(tableWin,editWin))
        btnBack.grid(column=6, row=2, pady=20)
        
        
        
        editWin.mainloop()
            
            
    def edit(event):
        global Baza
        def clickSave(ind=None,root1=None,root2=None):
            global Baza
            nazv=txt.get() 
            tip=txt1.get()
            brend=txt2.get()
            ves=txt3.get()
            cena=txt4.get()
            tel=txt5.get()
            adr=txt6.get()                     
            Baza['Название'][Baza.loc[Baza['ID'] == ind].index] = nazv
            Baza['Тип'][Baza.loc[Baza['ID'] == ind].index] = tip
            Baza['Бренд'][Baza.loc[Baza['ID'] == ind].index] = brend
            Baza['Вес/Объем'][Baza.loc[Baza['ID'] == ind].index] = float(ves)
            Baza['Цена'][Baza.loc[Baza['ID'] == ind].index] = float(cena)
            Baza['Телефон'][Baza.loc[Baza['ID'] == ind].index] = tel
            Baza['Адрес'][Baza.loc[Baza['ID'] == ind].index] = adr
            
            clck7()       
            Back(root1,root2)
            
        if(event.keycode == 46):
            try:                
                selected_item = table.selection()[0]
                curItem = table.focus()
                i = table.item(curItem)['values'][0]                
                table.delete(selected_item)
                Baza = Baza.drop(Baza.loc[Baza['ID'] == i].index)
            except:
                pass
                
            
        if(event.keycode == 13):
            editWin=tk.Tk()
            HideWin(tableWin)
            editWin.protocol("WM_DELETE_WINDOW",lambda: Back(tableWin,editWin))
            selected_item = table.selection()[0]
            curItem = table.focus()
            i = table.item(curItem)['values'][0]
            lb1 = tk.Label(editWin, text='ID',  
                                width=10, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
            lb2 = tk.Label(editWin, text='Название',  
                                width=35, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
            lb3 = tk.Label(editWin, text='Тип',  
                                width=28, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
            lb4 = tk.Label(editWin, text='Бренд', 
                                width=23, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
            lb5 = tk.Label(editWin, text='Вес/Объем',  
                                width=10, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
            lb6 = tk.Label(editWin, text='Цена',  
                                width=13, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
            lb7 = tk.Label(editWin, text='Телефон', 
                                width=16, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
            lb8 = tk.Label(editWin, text='Адрес', 
                                width=48, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
            lb9 = tk.Label(editWin, text=i,  
                                width=10, height=1, relief="groove",bg='#dee7ee', fg='#806d98')
            lb1.grid(column=0, row=0)
            lb2.grid(column=1, row=0)
            lb3.grid(column=2, row=0)
            lb4.grid(column=3, row=0)
            lb5.grid(column=4, row=0)
            lb6.grid(column=5, row=0)
            lb7.grid(column=6, row=0)
            lb8.grid(column=7, row=0)
            lb9.grid(column=0, row=1)
            txt = tk.Entry(editWin,width=40) 
            
            txt1 = tk.Entry(editWin,width=33)
            txt2 = tk.Entry(editWin,width=28)
            txt3 = tk.Entry(editWin,width=12)
            txt4 = tk.Entry(editWin,width=15)
            txt5 = tk.Entry(editWin,width=18)
            txt6 = tk.Entry(editWin,width=53)
            txt.insert(0, Baza['Название'][i-1])
            txt1.insert(0, Baza['Тип'][i-1])
            txt2.insert(0, Baza['Бренд'][i-1])
            txt3.insert(0, Baza['Вес/Объем'][i-1])
            txt4.insert(0, Baza['Цена'][i-1])
            txt5.insert(0, Baza['Телефон'][i-1])
            txt6.insert(0, Baza['Адрес'][i-1])
                
                
                
            txt.grid(column=1, row=1, pady=20)
            txt1.grid(column=2, row=1, pady=20) 
            txt2.grid(column=3, row=1, pady=20)
            txt3.grid(column=4, row=1, pady=20) 
            txt4.grid(column=5, row=1, pady=20)
            txt5.grid(column=6, row=1, pady=20) 
            txt6.grid(column=7, row=1, pady=20)
            btn = tk.Button(editWin,  text='Сохранить', 
                         relief="raised",width=48, height=1, bg='#10e701',  fg=color_fg,command=lambda:clickSave(ind=i,root1=tableWin,root2=editWin))
            btn.grid(column=7, row=2, pady=20)
            btnBack = tk.Button(editWin,  text='Назад', relief="raised",width=13, height=1, bg=color2_bg,  fg=color_fg,command=lambda: Back(tableWin,editWin))
            btnBack.grid(column=6, row=2, pady=20)
            
            
            
            editWin.mainloop()
            
            
            
            
            
    tableWin=tk.Tk()
    tableWin.minsize(1300,400)
    tableWin.title('Project 4')
    tableWin.iconbitmap(workDir + 'Graphics/icon.ico')
    HideWin(mainR)   
    
    
    tableWin.configure(bg='white')
    frameForBt = tk.Frame(tableWin)
    frameForBt.configure(bg='white')
    frameForBt.pack(anchor="nw")
    table = ttk.Treeview(tableWin, show="headings", selectmode="browse")
    
    headings = tuple(Baza.columns)
    rows = Baza
    table["columns"]= headings
    table["displaycolumns"] = headings
    table.bind('<Key>',edit)
    table.bind('<Double-Button-1>',DK)
    
    for head in headings:
        
        table.heading(head, text=head, anchor=tk.CENTER)
        if (head=="ID"):
            table.column(head, width=40, anchor=tk.CENTER)                
        elif (head=="Название"):
            table.column(head, width=240, anchor=tk.W)
        elif (head=="Тип"):
            table.column(head, width=170, anchor=tk.CENTER)
        elif (head=="Вес/Объем"):
            table.column(head, width=60, anchor=tk.E)
        elif (head=="Цена"):
            table.column(head, width=80, anchor=tk.E)
        elif (head=="Бренд"):
            table.column(head, width=100, anchor=tk.W)
        elif (head=="Адрес"):
            table.column(head, width=290, anchor=tk.W)
        elif (head=="Телефон"):
            table.column(head, width=100, anchor=tk.CENTER)
        
   
    z=0
        
    for x in rows['ID']:
        k = []
        for y in rows:
            h = []
            h = (rows[y][rows['ID'] == x]).tolist()
            k.append(h[0])
        z+=1
        if(z%2==0):            
            table.insert('', tk.END, values = k, tag='4')
        elif(int(z)%2==1):
            table.insert('', tk.END, values = k, tag='3')
  
    scrolltable = tk.Scrollbar(tableWin, command=table.yview)
    table.configure(yscrollcommand=scrolltable.set)
    table.tag_configure('1', background='#07e8be')
    table.tag_configure('2', background='white')
    table.tag_configure('3', background='#9bbefe')
    table.tag_configure('4', background='white')
    table.tag_configure('5', background='#ff887d')
    table.tag_configure('6', background='white')
    table.tag_configure('7', background='#ffd84e')
    table.tag_configure('8', background='white')
    scrolltable.pack(side=tk.RIGHT, fill=tk.Y)
    table.pack(expand=tk.YES, fill=tk.BOTH, side = 'bottom')
    
   
    b1 = tk.Button(frameForBt,text="Сортировать по названию", width=20, height=1, relief="groove",bg='#11C0C0', fg='black',command = clck1) 
    b2 = tk.Button(frameForBt,text = "Сортировать по типу", width=20, height=1, relief="groove", bg='#11C0C0', fg='black', command = clck2) 
    b3 = tk.Button(frameForBt,text="Сортировать по цене", width=20, height=1, relief="groove", bg='#11C0C0',  fg='black', command = clck3) 
    b4 = tk.Button(frameForBt,text="Сортировать по бренду", width=20, height=1, relief="groove", bg='#11C0C0', fg='black', command = clck4)
    bid = tk.Button(frameForBt,text="Сортировать по ID", relief="groove",width=20, height=1, bg='#11C0C0',  fg='black', command = clck7) 
     
    button_del = tk.Button(frameForBt, text="Удалить", relief="raised",width=20, height=1, bg=color2_bg,  fg='black', command = delete)
    button_save = tk.Button(frameForBt, text="Сохранить", relief="raised",width=20, height=1, bg='#10e701',  fg='black', command = saving)

                            
    
    

    button_save.grid(row=0,column=1,padx = 5)
    button_del.grid(row=0,column=2,padx = 5)
    
    bid.grid(row=1,column=0)
    b1.grid(row=1,column=1,padx = 10) 
    b2.grid(row=1,column=2,padx = 10) 
    b4.grid(row=1,column=3,padx = 10)
    b3.grid(row=1,column=4,padx = 10) 
    
    
    
    
    btnBack = tk.Button(frameForBt,  text='Назад', width=10, height=1, relief="raised", bg='#04915e', fg='black', command=lambda: Back(mainR,tableWin))
    btnBack.grid(row=0,column=0)
    tableWin.mainloop()

def Otchet(mainR=None):
    t = Baza['Бренд']
    t = set(t)
    t = list(t)
    k1 = len(t)
    
    h = Baza['Тип']
    h = set(h)
    h = list(h)
    k2 = len(h)
    
    po = (sum(Baza['Цена'])/len(Baza['Цена']))
    po = "%.2f" % po
    def clck1(bt,cmb1,cmb2,root1=None):
        try:
            f = open(workDir+'/Output/Полученный отчет.txt', 'a')
            o = cmb1.get()
            o2 = cmb2.get()
            f.write('Количество товаров: ' + str(Baza['ID'].iloc[-1]) + '\n')
            f.write('Количество Типов: ' + str(k2) + '\n')
            f.write('Количество Брендов: ' + str(k1) + '\n')
            f.write('Средняя арифметическая Цен: ' + str(po) + '\n')
            f.write('Количество товаров типа ' + o + ': ' + str(len(Baza[Baza['Тип'] == o])) + '\n')
            f.write('Количество товаров Бренда ' + o2 + ': ' + str(len(Baza[Baza['Бренд'] == o2])) + '\n')
            blabla = ('Количество товаров: ' + str(Baza['ID'].iloc[-1]) + '\n' + 
                      'Количество Типов: ' + str(k2) + '\n' + 
                      ('Количество Брендов: ' + str(k1) + '\n') + 
                      'Средняя арифметическая Цен: ' + str(po) + '\n' + 
                      'Количество товаров типа ' + o + ': ' + str(len(Baza[Baza['Тип'] == o])) + '\n' + 
                      'Количество товаров Бренда ' + o2 + ': ' + str(len(Baza[Baza['Бренд'] == o2])) + '\n')
            f.close()
            bt['text']=('Успешно')
            bt.config(state = 'disable')
            ot = tk.Tk()
            HideWin(root1)
            ot.iconbitmap(workDir + 'Graphics\\icon.ico')
            ot.title('Project 4')
        
            lblot = tk.Label(ot, text= blabla,  
                   width=40, height=8, relief="groove",bg='#dee7ee', fg='black')
            lblot.grid(column=1, row=1,padx=3,pady=3)
            
            btnBack = tk.Button(ot,  text='Назад', activebackground=color_abg,
                        activeforeground=colro_afg, width=15, height=1, 
                        relief="groove", bg=color_abg, 
                        font=('Comic Sans MS', 11), fg='black',
                        command=lambda: Back(otchWin,ot))
            btnBack.grid(column=1, row=2,padx=3,pady=3)
            
            wo = ot.winfo_screenwidth() 
            ho = ot.winfo_screenheight() 
            wo = wo//2
            ho = ho//2
            wo = wo - 200 
            ho = ho - 200
            ot.geometry('290x180+{}+{}'.format(wo, ho))
            ot.configure(bg='white')
            ot.protocol("WM_DELETE_WINDOW",lambda: Back(root1,ot))
            ot.mainloop()
        except:
            pass
        
            
                    
    def clck4(bt,cmb2):
        o = cmb2.get()
        y_pos = np.arange(len(Baza['Название'][Baza['Бренд'] == o].tolist()))
        height = Baza['Цена'][Baza['Бренд'] == o].tolist()
        plt.bar(y_pos, height, color = 'orange', width = 0.4)
        
        names = (Baza['Название'][Baza['Бренд'] == o].tolist())
        plt.xticks(y_pos, names, rotation=20, fontsize = 8)
        
        plt.title('Бренд: ' + o + ' - График по цене')
       
        plt.show()
            
    def clck5(bt,cmb1):
        o = cmb1.get()
        y_pos = np.arange(len(Baza['Название'][Baza['Тип'] == o].tolist()))
        height = Baza['Цена'][Baza['Тип'] == o].tolist()
        plt.bar(y_pos, height, color = 'orange', width = 0.4)
        
        names = (Baza['Название'][Baza['Тип'] == o].tolist())
        plt.xticks(y_pos, names, rotation=20, fontsize = 8)
        
        plt.title('Тип: ' + o + ' - График по цене')
        
        plt.show()
            
    def clck6(bt,cmb2):
        o = cmb2.get()
        y_pos = np.arange(len(Baza['Название'][Baza['Бренд'] == o].tolist()))
        height = Baza['Вес/Объем'][Baza['Бренд'] == o].tolist()
        plt.bar(y_pos, height, color = 'orange', width = 0.4)
        names = (Baza['Название'][Baza['Бренд'] == o].tolist())
        plt.xticks(y_pos, names, rotation=20, fontsize = 8)
        plt.title('Бренд: ' + o + ' - График по весу/объему')
        plt.show()
            
    def clck7(bt,cmb1):
        o = cmb1.get()
        y_pos = np.arange(len(Baza['Название'][Baza['Тип'] == o].tolist()))
        height = Baza['Вес/Объем'][Baza['Тип'] == o].tolist()
        plt.bar(y_pos, height, color = 'orange', width = 0.4)
        
        names = (Baza['Название'][Baza['Тип'] == o].tolist())
        plt.xticks(y_pos, names, rotation=20, fontsize = 8)
        
        plt.title('Тип: ' + o + ' - График по весу/объему')
       
        plt.show()    
        
    otchWin=tk.Tk()
    otchWin.iconbitmap(workDir + 'Graphics/icon.ico')
    otchWin.title('Project 4')
    HideWin(mainR)
    otchWin.protocol("WM_DELETE_WINDOW",lambda: Back(mainR,otchWin))
    
    btnStat = tk.Button(otchWin, text='Составить стат. отчет', 
                    activebackground=color_abg, activeforeground=colro_afg,
                    width=24, height=1, relief="flat", bg=color_abg,
                    font=('Comic Sans MS', 11), fg='black', 
                    command = lambda: clck1(btnStat,cmb1,cmb2,otchWin))
    btnStat.grid(column=1, row=3,padx=3,pady=3)
    
    
    
    
    
    lblTip = tk.Label(otchWin, text='Выберите тип',  
                   width=24, height=2, relief="groove",bg='#dee7ee', fg='black')
    lblTip.grid(column=1, row=1,padx=3,pady=3)
    
    cmb1 = ttk.Combobox(otchWin)
    h[0] = 'Веревки'
    cmb1['values'] = h 
    cmb1['font']= ('Comic Sans MS', 11)
    cmb1['width']=22
    cmb1.current(0)     
    cmb1.grid(column=2, row=1,padx=3,pady=3)
    
    lblBr = tk.Label(otchWin, text='Выберите бренд',  
                   width=24, height=2, relief="groove",
                   bg='#dee7ee', fg='black')
    lblBr.grid(column=1, row=2,padx=3,pady=3)
    
    cmb2 = ttk.Combobox(otchWin)
    t[0] = 'СВФС'
    cmb2['values'] = t
    cmb2.current(0)       
    cmb2['font']= ('Comic Sans MS', 11)
    cmb2['width']=22
    cmb2.grid(column=2, row=2,padx=3,pady=3)
    
    
    btnGr1 = tk.Button(otchWin, text='График тов. по бр. и цене', 
                    activebackground=color_abg, activeforeground=colro_afg,
                    width=24, height=1, relief="groove", bg=color_abg,
                    font=('Comic Sans MS', 11), fg='black',
                    command = lambda:clck4(btnGr1,cmb2))
    btnGr1.grid(column=3, row=3,padx=3,pady=3)
    
    btnGr2 = tk.Button(otchWin, text='График тов. по типу и цене', 
                    activebackground=color_abg, activeforeground=colro_afg,
                    width=24, height=1, relief="groove", bg=color_abg, 
                    font=('Comic Sans MS', 11), fg='black',
                    command = lambda:clck5(btnGr2,cmb1))
    btnGr2.grid(column=2, row=3,padx=3,pady=3)
    
    btnGr3 = tk.Button(otchWin, text='График тов. по бр. и весу', 
                    activebackground=color_abg, activeforeground=colro_afg,
                    width=24, height=1, relief="groove", bg=color_abg,
                    font=('Comic Sans MS', 11), fg='black',
                    command = lambda:clck6(btnGr3,cmb2))
    btnGr3.grid(column=2, row=4,padx=3,pady=3)
    
    btnGr4 = tk.Button(otchWin, text='График тов. по типу и весу', 
                    activebackground=color_abg, activeforeground=colro_afg
                    , width=24, height=1, relief="groove", bg=color_abg,
                    font=('Comic Sans MS', 11), fg='black',
                    command = lambda:clck7(btnGr4,cmb1))
    btnGr4.grid(column=1, row=4,padx=3,pady=3)
    
    btnBack = tk.Button(otchWin,  text='Назад', activebackground=color_abg,
                        activeforeground=colro_afg, width=24, height=1, 
                        relief="groove", bg=color_abg, 
                        font=('Comic Sans MS', 11), fg='black',
                        command=lambda: Back(mainR,otchWin))
    
    btnBack.grid(row=4,column=3)
    
    
    w = otchWin.winfo_screenwidth() 
    h = otchWin.winfo_screenheight() 
    w = w//2
    h = h//2
    w = w - 200 
    h = h - 200
    
    otchWin.geometry('700x180+{}+{}'.format(w, h))
    otchWin.configure(bg='white')
    otchWin.resizable(False, False)
    
    
    
    otchWin.mainloop()



def findEl(mainR=None):
    findWin=tk.Tk()
    findWin.minsize(1300,400)
    findWin.title('Project 4')
    findWin.iconbitmap(workDir + 'Graphics/icon.ico')
    HideWin(mainR)
    findWin.protocol("WM_DELETE_WINDOW",lambda: Back(mainR,findWin))
    findWin.configure(bg='white')

    frameForfd = tk.Frame(findWin)
    frameForfd.configure(bg='white')
    frameForfd.pack(side='top')
    headings = tuple(Baza.columns)
    
    rows = Baza    
    
    
    table = ttk.Treeview(findWin, show="headings", selectmode="browse")
    table["columns"]= headings
    table["displaycolumns"] = headings    
    for head in headings:
        table.heading(head, text=head, anchor=tk.CENTER)
        if (head=="ID"):
            table.column(head, width=40, anchor=tk.CENTER)                
        elif (head=="Название"):
            table.column(head, width=240, anchor=tk.W)
        elif (head=="Тип"):
            table.column(head, width=170, anchor=tk.CENTER)
        elif (head=="Вес/Объем"):
            table.column(head, width=60, anchor=tk.E)
        elif (head=="Цена"):
            table.column(head, width=80, anchor=tk.E)
        elif (head=="Бренд"):
            table.column(head, width=100, anchor=tk.W)
        elif (head=="Адрес"):
            table.column(head, width=290, anchor=tk.W)
        elif (head=="Телефон"):
            table.column(head, width=100, anchor=tk.CENTER)
            
        
    z=0
        
    for x in rows['ID']:
        k = []
        for y in rows:
            h = []
            h = (rows[y][rows['ID'] == x]).tolist()
            k.append(h[0])
        z+=1
        if(z%2==0):
            table.insert('', tk.END, values = k, tag='1')
        elif(int(z)%2==1):
            table.insert('', tk.END, values = k, tag='2')
  
    scrolltable = tk.Scrollbar(findWin, command=table.yview)
    table.configure(yscrollcommand=scrolltable.set)
    table.tag_configure('1', background='#07e8be')
    table.tag_configure('2', background='white')
    table.tag_configure('3', background='#9bbefe')
    table.tag_configure('4', background='white')
    table.tag_configure('5', background='#ff887d')
    table.tag_configure('6', background='white')

    scrolltable.pack(side=tk.RIGHT, fill=tk.Y)
    table.pack(expand=tk.YES, fill=tk.BOTH, side = 'bottom')
   
    
    
    def find(cmb1,txt1):
        o = cmb1.get()
        l = txt1.get()
        global Baza
        z = 0
        table.delete(*table.get_children())
        if l == '':
            Kaza = Baza
            for x in Kaza['ID']:
                k = []
                for y in Kaza:
                    h = []
                    h = (Kaza[y][Kaza['ID'] == x]).tolist()
                    k.append(h[0])
                z+=1
                if(z%2==0):
                    table.insert('', tk.END, values = k, tag='3')
                elif(z%2==1):
                    table.insert('', tk.END, values = k, tag='4')
        else:   
            Kaza = Baza   
            po = Baza[o].tolist()
            for x in po:
                k = []
                if(l.lower() in x.lower()):
                    for y in Kaza:
                        h = []
                        h = (Kaza[y][Kaza[o] == x]).tolist()
                        k.append(h[0])
                    z+=1
                    if(z%2==0):
                        table.insert('', tk.END, values = k, tag='5')
                    elif(z%2==1):
                        table.insert('', tk.END, values = k, tag='6')
                    
        

    poisk = tk.Button(frameForfd,text="Поиск", activebackground=color_abg, activeforeground=colro_afg, width=12, height=1, relief="groove", bg=color_abg, font=('Comic Sans MS', 11), fg='black', command = lambda: find(cmb1,txt1))
    
    cmb1 = ttk.Combobox(frameForfd)
    cmb1['values'] = ['Название', 'Тип', 'Бренд'] 
    cmb1['font']= ('Comic Sans MS', 12)
    cmb1['width']=11
    cmb1.current(0)
    cmb1.grid(column =0 ,row=0)
    
    btnBack = tk.Button(findWin,  text='Назад', width=10, height=1, relief="raised", bg='#04915e', fg='black',command=lambda: Back(mainR,findWin))
    btnBack.place(x=0, y=0)
    
    
    txt1 = tk.Entry(frameForfd,width=40,font=('Comic Sans MS', 13),relief="groove")  
    txt1.grid(row=0,column=1,padx = 5)
    poisk.grid(row=0,column=2)
    txt1.config({"background": "pink"})
    findWin.mainloop()