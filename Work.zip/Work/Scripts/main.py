"""
Скрипт содерджит главное 
окно приложения.
Главный скрипт для работы с БД
Автор: Юсупов,Саруханян
Группа: БИВ181
Бригада: 4
"""

import tkinter as tk
import pandas as pd
import os
import sys



#########################
#menu 
color_bgEn = "#2a5885"
color_abg = "#3F5AF1"  
colro_afg = "#ffffff"
color_bg = "#4a75a8"
color_fg = "white"
#positive


color1_bgEn = "#087708"
color1_abg = "#57bf57"  
color1_bg = "#10d410"
color1_fg = "white"

#negative


color2_bgEn = "#841a0a"
color2_abg = "#a51a04"  
color2_bg = "#e82d0f"
color2_fg = "white"
##########################






workDir = os.getcwd()
workDir = workDir.replace("Scripts","")   
try:
    sys.path.insert(0,workDir+"Library")
    import GrAndDF as gd
except:
    pass
pd.options.mode.chained_assignment = None

q = ""

Baza = pd.DataFrame(index=None, columns=None)
mainRoot=tk.Tk()
mainRoot.title('Project 4')
mainRoot.iconbitmap(workDir + 'Graphics/icon.ico')





b1 = tk.Button(mainRoot, text="Загрузить базу", activebackground=color_abg, activeforeground=colro_afg, width=24, height=1, relief="flat", bg=color_bg, font=('Comic Sans MS', 11), fg=color_fg, command=lambda:gd.Open(mainRoot,b2,b3,b4,b6))
b2 = tk.Button(mainRoot, state='disabled', text="Показать базу", activebackground=color_abg, activeforeground=colro_afg, width=24, height=1, relief="flat", bg=color_bg, font=('Comic Sans MS', 11), fg=color_fg, command=lambda:gd.Pokaz(mainR=mainRoot))
b3 = tk.Button(mainRoot, state='disabled', text="Добавить товар", activebackground=color_abg, activeforeground=colro_afg, width=24, height=1, relief="flat", bg=color_bg, font=('Comic Sans MS', 11), fg=color_fg,command=lambda:gd.Add(mainRoot))
b4 = tk.Button(mainRoot, state='disabled', text="Составить отчет", activebackground=color_abg, activeforeground=colro_afg, width=24, height=1, relief="flat", bg=color_bg, font=('Comic Sans MS', 11), fg=color_fg, command=lambda:gd.Otchet(mainRoot))
b6 = tk.Button(mainRoot, state='disabled', text="Поиск", activebackground=color_abg, activeforeground=colro_afg, width=24, height=1, relief="flat", bg=color_bg, font=('Comic Sans MS', 11), fg=color_fg,command=lambda: gd.findEl(mainR=mainRoot))
b5 = tk.Button(mainRoot, text="Выход", activebackground=color_abg, activeforeground=colro_afg, width=24, height=1, relief="flat", bg=color_bg, font=('Comic Sans MS', 11), fg=color_fg,command=lambda: mainRoot.destroy())

b1.bind("<Enter>",(lambda event:b1.configure(bg = color_bgEn, relief="groove")))
b1.bind("<Leave>",(lambda event:b1.configure(bg = color_bg, relief="flat")))               
b2.bind("<Enter>",(lambda event:b2.configure(bg = color_bgEn, relief="groove")))
b2.bind("<Leave>",(lambda event:b2.configure(bg = color_bg, relief="flat")))      
b3.bind("<Enter>",(lambda event:b3.configure(bg = color_bgEn, relief="groove")))
b3.bind("<Leave>",(lambda event:b3.configure(bg = color_bg, relief="flat")))
b4.bind("<Enter>",(lambda event:b4.configure(bg = color_bgEn, relief="groove")))
b4.bind("<Leave>",(lambda event:b4.configure(bg = color_bg, relief="flat")))      
b5.bind("<Enter>",(lambda event:b5.configure(bg = color_bgEn, relief="groove")))
b5.bind("<Leave>",(lambda event:b5.configure(bg = color_bg, relief="flat")))      
b6.bind("<Enter>",(lambda event:b6.configure(bg = color_bgEn, relief="groove")))
b6.bind("<Leave>",(lambda event:b6.configure(bg = color_bg, relief="flat")))
               
               
b1.pack(padx=10, pady=10)
b2.pack(padx=10, pady=10)
b3.pack(padx=10, pady=10)
b4.pack(padx=10, pady=10)
b6.pack(padx=10, pady=10)
b5.pack(padx=10, pady=10)
w = mainRoot.winfo_screenwidth() 
h = mainRoot.winfo_screenheight() 
w = w//2
h = h//2
w = w - 200 
h = h - 200


mainRoot.geometry('330x400+{}+{}'.format(w, h))
mainRoot.minsize(330,440)
mainRoot.configure(bg='white')
mainRoot.mainloop()